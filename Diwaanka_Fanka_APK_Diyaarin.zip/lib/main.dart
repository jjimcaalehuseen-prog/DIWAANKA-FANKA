import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = await openDatabase(
    p.join(await getDatabasesPath(), 'diwaanka_fanka.db'),
    version: 1,
    onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE records(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          category TEXT NOT NULL,
          name TEXT NOT NULL,
          singer TEXT, poet TEXT, musician TEXT,
          year TEXT, genre TEXT, notes TEXT
        )
      ''');
    },
  );
  runApp(DiwaankaApp(db: db));
}

class DiwaankaApp extends StatelessWidget {
  const DiwaankaApp({super.key, required this.db});
  final Database db;

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Diwaanka Fanka',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xffbd9140),
          brightness: Brightness.dark),
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xff101820),
    ),
    home: HomePage(db: db),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.db});
  final Database db;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  int refresh = 0;
  final tabs = const ['Guudmar', 'Heesaha', 'Fannaaniinta', 'Abwaannada', 'Muusikiistayaasha'];
  final categories = const ['Hees', 'Fannaan', 'Abwaan', 'Muusikiiste'];
  String get category => tab == 1 ? 'Hees' : tab == 2 ? 'Fannaan' : tab == 3 ? 'Abwaan' : 'Muusikiiste';

  Future<int> count(String c) async {
    final r = await widget.db.rawQuery('SELECT COUNT(*) n FROM records WHERE category=?', [c]);
    return Sqflite.firstIntValue(r) ?? 0;
  }

  Future<void> addRecord() async {
    final result = await showDialog<Map<String, String>>(
      context: context, builder: (_) => AddDialog(category: category));
    if (result == null || result['name']!.trim().isEmpty) return;
    await widget.db.insert('records', {'category': category, ...result});
    setState(() => refresh++);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('DIWAANKA FANKA', style: TextStyle(fontWeight: FontWeight.bold)),
      Text('Kaydka fanka Soomaaliyeed', style: TextStyle(fontSize: 12)),
    ])),
    body: tab == 0 ? dashboard() : records(),
    floatingActionButton: tab == 0 ? null : FloatingActionButton(
      onPressed: addRecord, child: const Icon(Icons.add)),
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard), label: 'Guudmar'),
        NavigationDestination(icon: Icon(Icons.music_note), label: 'Heesaha'),
        NavigationDestination(icon: Icon(Icons.mic), label: 'Fannaan'),
        NavigationDestination(icon: Icon(Icons.edit_note), label: 'Abwaan'),
        NavigationDestination(icon: Icon(Icons.piano), label: 'Muusikiiste'),
      ],
    ),
  );

  Widget dashboard() => ListView(padding: const EdgeInsets.all(16), children: [
    Text('Ku soo dhowow diiwaanka', style: Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height: 8),
    const Text('Halkan ku kaydi heesaha, fannaaniinta, abwaannada iyo muusikiistayaasha Soomaaliyeed.'),
    const SizedBox(height: 16),
    for (var i = 0; i < categories.length; i++)
      Card(child: ListTile(
        leading: const Icon(Icons.library_music),
        title: Text(tabs[i + 1]),
        trailing: FutureBuilder<int>(future: count(categories[i]),
          builder: (_, s) => Text('${s.data ?? 0}', style: Theme.of(context).textTheme.headlineSmall)),
      )),
    const SizedBox(height: 12),
    const Text('Xogta waxaa lagu kaydiyaa telefoonkan. Magacyada si isku mid ah u qor si tirintu u saxnaato.'),
  ]);

  Widget records() => RecordsList(
    key: ValueKey('$tab-$refresh'), db: widget.db, category: category,
    onDelete: () => setState(() => refresh++));
}

class RecordsList extends StatefulWidget {
  const RecordsList({super.key, required this.db, required this.category, required this.onDelete});
  final Database db; final String category; final VoidCallback onDelete;
  @override State<RecordsList> createState() => _RecordsListState();
}
class _RecordsListState extends State<RecordsList> {
  String search = '';
  Future<List<Map<String, Object?>>> load() => widget.db.query('records',
    where: 'category=? AND name LIKE ?', whereArgs: [widget.category, '%$search%'],
    orderBy: 'name COLLATE NOCASE');
  Future<int> songCount(String field, String name) async {
    final r = await widget.db.rawQuery(
      'SELECT COUNT(*) n FROM records WHERE category=? AND lower($field)=lower(?)',
      ['Hees', name]);
    return Sqflite.firstIntValue(r) ?? 0;
  }
  @override Widget build(BuildContext context) => Column(children: [
    Padding(padding: const EdgeInsets.all(12), child: TextField(
      onChanged: (v) => setState(() => search = v),
      decoration: InputDecoration(labelText: 'Raadi ${widget.category}',
        prefixIcon: const Icon(Icons.search), border: const OutlineInputBorder()))),
    Expanded(child: FutureBuilder<List<Map<String, Object?>>>(
      future: load(), builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final rows = snap.data!;
        if (rows.isEmpty) return const Center(child: Text('Weli xog laguma darin. Taabo + si aad u bilowdo.'));
        return ListView.builder(itemCount: rows.length, itemBuilder: (_, i) {
          final r = rows[i]; final name = r['name'] as String;
          final field = widget.category == 'Fannaan' ? 'singer' :
              widget.category == 'Abwaan' ? 'poet' : 'musician';
          return Card(child: ListTile(
            title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: widget.category == 'Hees'
              ? Text('Fannaan: ${r['singer'] ?? '—'}  •  Abwaan: ${r['poet'] ?? '—'}\nMuusikiiste: ${r['musician'] ?? '—'}\n${r['year'] ?? ''} ${r['genre'] ?? ''}\n${r['notes'] ?? ''}')
              : FutureBuilder<int>(future: songCount(field, name),
                  builder: (_, s) => Text('Heesaha ku xiran: ${s.data ?? 0}\n${r['notes'] ?? ''}')),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
              final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                title: const Text('Tirtir xogtan?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Ka noqo')),
                  FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Tirtir')),
                ]));
              if (yes == true) { await widget.db.delete('records', where: 'id=?', whereArgs: [r['id']]); widget.onDelete(); }
            }),
          ));
        });
      })),
  ]);
}

class AddDialog extends StatefulWidget {
  const AddDialog({super.key, required this.category});
  final String category;
  @override State<AddDialog> createState() => _AddDialogState();
}
class _AddDialogState extends State<AddDialog> {
  final controllers = <String, TextEditingController>{
    for (final k in ['name','singer','poet','musician','year','genre','notes']) k: TextEditingController()
  };
  @override void dispose() { for (final c in controllers.values) { c.dispose(); } super.dispose(); }
  Widget field(String key, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: TextField(controller: controllers[key],
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())));
  @override Widget build(BuildContext context) => AlertDialog(
    title: Text('Ku dar ${widget.category}'),
    content: SizedBox(width: 420, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      field('name', widget.category == 'Hees' ? 'Magaca heesta *' : 'Magaca *'),
      if (widget.category == 'Hees') ...[
        field('singer', 'Fannaanka'), field('poet', 'Abwaanka'),
        field('musician', 'Muusikiistaha'), field('year', 'Sanadka'),
        field('genre', 'Nooca heesta'),
      ],
      field('notes', 'Faahfaahin'),
    ]))),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Ka noqo')),
      FilledButton(onPressed: () => Navigator.pop(context, {
        for (final e in controllers.entries) e.key: e.value.text.trim()
      }), child: const Text('Kaydi')),
    ],
  );
}
